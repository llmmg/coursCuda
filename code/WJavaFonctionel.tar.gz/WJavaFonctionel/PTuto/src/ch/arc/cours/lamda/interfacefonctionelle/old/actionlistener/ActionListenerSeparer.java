
package ch.arc.cours.lamda.interfacefonctionelle.old.actionlistener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionListenerSeparer implements ActionListener
	{

	/*------------------------------------------------------------------*\
	|*							Constructeurs							*|
	\*------------------------------------------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	@Override public void actionPerformed(ActionEvent e)
		{
		System.out.println("click 0");
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Attributs Private						*|
	\*------------------------------------------------------------------*/
	}
