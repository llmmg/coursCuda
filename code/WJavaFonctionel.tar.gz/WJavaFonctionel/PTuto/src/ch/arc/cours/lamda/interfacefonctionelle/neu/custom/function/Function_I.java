
package ch.arc.cours.lamda.interfacefonctionelle.neu.custom.function;


@FunctionalInterface
public interface Function_I
	{
	public double value(double x);
	}

