
package ch.arc.cours.lamda.interfacefonctionelle.neu.custom.function.compose;

import ch.arc.cours.lamda.interfacefonctionelle.neu.custom.function.Function_I;

public class FunctionCompose
	{

	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	/**
	 * (h 0 g)(x) = g(h(x))
	 *
	 * classe interne anonyme
	 */
	public static Function_I composition1(Function_I h, Function_I g)
		{
		// TODO
		}

	/**
	 * (h 0 g)(x) = g(h(x))
	 *
	 * lamda dans variable
	 */
	public static Function_I composition2(Function_I h, Function_I g)
		{
		// TODO
		}

	/**
	 * (h 0 g)(x) = g(h(x))
	 *
	 * lamda
	 */
	public static Function_I composition3(Function_I h, Function_I g)
		{
		// TODO
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	}
